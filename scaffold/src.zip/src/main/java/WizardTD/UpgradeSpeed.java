package WizardTD;

public class UpgradeSpeed extends GameplayActions {
    public static final double FIRING_SPEED_UPGRADE = 1.5;

    public UpgradeSpeed() {
        super(256, '2', "U2", "Upgrade\nspeed");
    }

}
