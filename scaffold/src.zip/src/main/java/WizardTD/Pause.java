package WizardTD;

public final class Pause extends GameplayActions {
    public Pause() {
        super(100, 'p', "P ", "PAUSE");
    }
}
