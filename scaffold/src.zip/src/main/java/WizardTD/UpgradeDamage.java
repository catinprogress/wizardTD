package WizardTD;

public final class UpgradeDamage extends GameplayActions {
    public static final double DAMAGE_MULTIPLIER_UPGRADE = 0.5;

    public UpgradeDamage() {
        super(308, '3', "U3", "Upgrade\ndamage");
    }
}
