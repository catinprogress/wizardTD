package WizardTD;

public final class FastForward extends GameplayActions{
    public FastForward() {
        super(48, 'f', "FF", "2x speed");
    }

}
